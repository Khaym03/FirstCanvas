import {
    ctx, notes, roWidth, rowX
} from './index.js';

const pallet = {
            fucsia: '#FF0048',
            pink: '#F795C2',
            yellow: '#F2E307',
            orange: '#F27405'
        };



export class Ball {
    
   constructor(x, y, radius, color, speed, sounds, color2) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.color = color;
        this.speed = speed;
        this.moveX = 1 * this.speed;
        this.moveY = 1 * this.speed;
        this.sounds = sounds;
        this.color2 = color2;
        
    }
    
    draw(ctx) {
        
        ctx.beginPath();
        ctx.fillStyle = this.color;
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
        ctx.fill();
        ctx.closePath();
        
    }
    
    update() {
        this.draw(ctx);
        // 450
        if((this.x + this.radius) > (roWidth + 50)){
            this.moveX = -this.moveX;
            this.sounds[0].play();
            this.color = this.color2
        }
        // 40
        if((this.x - this.radius) < (rowX - 10)){
            this.moveX = -this.moveX;
            this.sounds[1].play();
            this.color = 'white';
        }
    
        this.x += this.moveX;
    }
}

