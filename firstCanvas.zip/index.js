export { ctx, notes, roWidth, rowX }

import { Rail } from './rail.js';
import { Ball } from './ball.js';

const get = selector => document.querySelector(selector);

const heightOfWrapper = get('#wrapper').offsetWidth;
const widthOfWrapper = get('#wrapper').offsetWidth;

const canvas = get('#canvas');
const ctx = canvas.getContext('2d');

const cWidth = canvas.width = widthOfWrapper;
const cHeight = canvas.height = widthOfWrapper;
const colorForLines = '#1b1b1b';



let notes = [];

for (let i = 0; i < 8; i++) {
    let str = `${i + 1}.mp3`
    notes.push(str)
}

    const pair1 = [
        new Audio(`./notas/${notes[0]}`),
        new Audio(`./notas/${notes[1]}`)
    ];
    
    const pair2 = [
        new Audio(`./notas/${notes[2]}`),
        new Audio(`./notas/${notes[3]}`)
    ];
    
    const pair3 = [
        new Audio(`./notas/${notes[4]}`),
        new Audio(`./notas/${notes[5]}`)
    ];
    
    const pair4 = [
        new Audio(`./notas/${notes[6]}`),
        new Audio(`./notas/${notes[7]}`)
    ];

canvas.width = widthOfWrapper;
canvas.height = widthOfWrapper;

canvas.style.background = 'black';

let positionOfLines = [
        (widthOfWrapper * 0.2),
        (widthOfWrapper * 0.4),
        (widthOfWrapper * 0.6),
        (widthOfWrapper * 0.8),
    ];

let [rowOne, rowTwo, rowThree, rowFour] = positionOfLines;

const roWidth = (widthOfWrapper * 0.8);

const rowX = widthOfWrapper * 0.1;

let speedCtrl = 0;

if( widthOfWrapper < 400) {
     speedCtrl = 1;
} else {
     speedCtrl = 2;
}

const lineOne = new Rail(rowX, rowOne, roWidth, 2, colorForLines);
const ballOne = new Ball(rowX, rowOne, 10, colorForLines, speedCtrl, pair1, '#FF0048');
lineOne.draw(ctx);
ballOne.draw(ctx);

const lineTwo = new Rail(rowX, rowTwo, roWidth, 2, colorForLines);
const ballTwo = new Ball(rowX, rowTwo, 10, colorForLines, (speedCtrl * 1.2), pair2, '#F795C2');
lineTwo.draw(ctx);
ballTwo.draw(ctx);

const lineThree = new Rail(rowX, rowThree, roWidth, 2, colorForLines);
const ballThree = new Ball(rowX, rowThree, 10, colorForLines, (speedCtrl * 1.4), pair3, '#F2E307');
lineThree.draw(ctx);
ballThree.draw(ctx);

const lineFour = new Rail(rowX, rowFour, roWidth, 2, colorForLines);
const ballFour = new Ball(rowX, rowFour, 10, colorForLines, (speedCtrl * 1.6), pair4, '#F27405');
lineFour.draw(ctx);
ballFour.draw(ctx);

let lastTime = 0;
let interval = 1000 / 60;
let timer = 0;

let elements = [lineOne, ballOne, lineTwo, ballTwo, lineThree, ballThree, lineFour, ballFour];

function animate(timestamp) {
    const deltaTime = timestamp - lastTime;
    lastTime = timestamp;
    ctx.clearRect(0, 0, cWidth, cHeight);
    
    elements.forEach(elem => elem.update());
    requestAnimationFrame(animate);
}

window.onload = () => {
    animate();
    note1.play();
};












